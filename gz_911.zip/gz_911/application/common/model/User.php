<?php

namespace app\common\model;

use think\Model;

class User extends Model
{
    //5.1中模型不会自动获取主键名称，必须设置pk属性
    protected $pk = 'id';

    //设置当前模型对应的完整数据表名称
    protected $table = 'bbs_user';
}
