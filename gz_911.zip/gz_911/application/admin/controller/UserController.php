<?php

namespace app\admin\controller;

use think\Controller;
use think\Request;
//添加时用到（模型model 一个数据表一个模型）
use app\common\model\User;

use Db;

class UserController extends Controller
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {
        // $users = User::select();//查询所有
        $users = User::paginate(2);//每页显示的条数 
        $page_string = $users->render();
        return view('user/index',['users' => $users,'page_string'=>$page_string]);

    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
        return view('user/create');
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //接收所有数据
        $form_data = $request -> post();

        //验证 用户名长度
        $userlen = strlen($form_data['username']);
        $user_str = $form_data['username'];
        if($userlen < 2){
            $this -> error('用户名不能小于2位','/user/create');
        }
        if(!preg_match('/^[A-Za-z0-9_]+$/u',$user_str)){
            $this -> error('用户名应为数字字母下划线','/user/create');
        };

        // $un = User::name($user_str)->field('username')->select();
        // dump($form_data['username']);
        // dump($un[['username']]);
        // if($form_data['username'] == $un['username']){
        //     $this -> error('用户名不能重复','/user/create');
        // }

        



        //密码与确认密码一致 一致后MD5加密存储
        if($form_data['password'] == $form_data['repass']){
            $form_data['password'] == md5($form_data['repass']);
        }else{
            $this -> error('密码不一致','/user/create');
        }

        //手机号验证
        $user_pho = $form_data['tel'];
        if(!preg_match("/^1[345678]{1}\d{9}$/",$user_pho)){
            $this -> error('手机号码格式不对','/user/create');
        }

        //以上是验证
        //注册时间
        $form_data['rtime'] = time();
        //注册ip
        $form_data['rip'] = ip2long($_SERVER['REMOTE_ADDR']);

        //这个true是过滤添加时数据库里面没有的字段
        try {
            //执行添加
            User::create($form_data,true);
        } catch (Exception $e) {
            //异常信息
            $this -> error('用户添加失败','/user/create');
        }
        //用户添加成功
        $this -> success('用户添加成功','/user/index');
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        $users = User::get($id);
        // dump($users);
        return view('user/edit',['users' => $users]);
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        $form_data = $request -> post();

        try {
            User::update($form_data,['id'=>$id]);    
        } catch (Exception $e) {
            return $this -> error('修改失败','/user/edit/'.$id);
        }
            return $this -> success('修改成功','/user/index');


     }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        $row = User::destroy($id);
        if ($row) {
            $this -> success('删除成功','/user/index');
        } else {
            $this -> error('删除失败','/user/index');
        }
    }
}
