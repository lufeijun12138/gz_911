<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
		
		//浏览器输入地址    模块 /  控制器      /方法
Route::rule('/user/create','admin/UserController/create');//用户添加
Route::rule('/user/save','admin/UserController/save');//用户保存数据
Route::rule('/user/index','admin/UserController/index');//用户列表页面
Route::rule('/user/delete/:id','admin/UserController/delete');//用户删除
Route::rule('/user/edit/:id','admin/UserController/edit');//用户修改
Route::rule('/user/update/:id','admin/UserController/update');//用户保存数据



//路由到模板  网页路径         文件夹/文件名(省略扩展名)
Route::view('/admin','admin@common/default');
Route::view('/','admin@common/default');


Route::rule('/test',function(){
	return 'test';
});


Route::get('think', function () {
    return 'hello,ThinkPHP5!';
});

Route::get('hello/:name', 'index/hello');

return [

];
