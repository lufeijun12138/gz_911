<?php /*a:2:{s:60:"D:\XAMPP\htdocs\gz_911\application/admin/view\user\edit.html";i:1536733989;s:65:"D:\XAMPP\htdocs\gz_911\application/admin/view\common\default.html";i:1536720499;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="/static/admin/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="/static/admin/css/main.css"/>
    <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/> -->
    <script type="text/javascript" src="js/libs/modernizr.min.js"></script>
</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">后台管理</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="index.html">首页</a></li>
                <li><a href="http://www.mycodes.net/" target="_blank">网站首页</a></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="#">管理员</a></li>
                <li><a href="#">修改密码</a></li>
                <li><a href="#">退出</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                        <li><a href="/user/index"><i class="icon-font">&#xe008;</i>用户管理</a></li>
                        <li><a href="/user/create"><i class="icon-font">&#xe005;</i>用户添加</a></li>

                   </ul>
                </li>
                <li>
                    <a href="#"><i class="icon-font">&#xe018;</i>系统管理</a>
                    <ul class="sub-menu">
                        <li><a href="system.html"><i class="icon-font">&#xe017;</i>系统设置</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe037;</i>清理缓存</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe046;</i>数据备份</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe045;</i>数据还原</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>




    


    <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list">
                <i class="icon-font"></i>
                <a href="/jscss/admin/design/">首页</a>
                <span class="crumb-step">&gt;</span>
                <a class="crumb-name" href="/jscss/admin/design/">作品管理</a>
                <span class="crumb-step">&gt;</span>
                <span>新增作品</span>
            </div>
        </div>
        <div class="result-wrap">
            <div class="result-content">
                <form action="/user/update/<?php echo htmlentities($users['id']); ?>" method="post" id="myform" name="myform" enctype="multipart/form-data">
                    <table class="insert-tab" width="100%">
                        <tbody>
                            <tr>
                                <th width="120"><i class="require-red">*</i>权限：</th>
                                <td>
                                    <select name="qx" id="catid" class="required">

                                        <option value="1"<?php if($users['qx'] == 1): ?>selected<?php endif; ?>>管理员</option>
                                        <option value="2"<?php if($users['qx'] == 2): ?>selected<?php endif; ?>>普通用户</option>
                                        <option value="3"<?php if($users['qx'] == 3): ?>selected<?php endif; ?>>普通管理员</option>
                                        <option value="4"<?php if($users['qx'] == 4): ?>selected<?php endif; ?>>教师</option>

                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><i class="require-red">*</i>用户名:</th>
                                <td>
                                    <input class="common-text required" id="title" name="username" size="50" value="<?php echo htmlentities($users['username']); ?>" type="text" />
                                </td>
                            </tr>
                            <tr>
                                <th><i class="require-red">*</i>性别:</th>
                                <td>
                                    <label><input class="common-text required" id="title" name="sex" size="50" value="w" type="radio" <?php if($users['sex'] == 'm'): ?>checked<?php endif; ?>>男</label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <label><input class="common-text required" id="title" name="sex" size="50" value="m" type="radio"<?php if($users['sex'] == 'w'): ?>checked<?php endif; ?>>女</label>
                                </td>
                            </tr>
                            <tr>
                                <th><i class="require-red">*</i>手机号:</th>
                                <td>
                                    <input class="common-text required" id="title" name="tel" size="50" value="<?php echo htmlentities($users['tel']); ?>" type="text">
                                </td>
                            </tr>
                            <tr>
                                <th></th>
                                <td>
                                    <input class="btn btn-primary btn6 mr10" value="提交" type="submit">
                                    <input class="btn btn6" onclick="history.go(-1)" value="返回" type="button">
                                </td>
                            </tr>
                        </tbody>
                        </table>
                </form>
            </div>
        </div>

    </div>
    <!--/main-->

    
</div>
</body>
</html>